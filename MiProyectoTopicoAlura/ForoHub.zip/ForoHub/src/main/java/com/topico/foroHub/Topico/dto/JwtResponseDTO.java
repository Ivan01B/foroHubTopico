package com.topico.foroHub.Topico.dto;

public record JwtResponseDTO(String token) {}