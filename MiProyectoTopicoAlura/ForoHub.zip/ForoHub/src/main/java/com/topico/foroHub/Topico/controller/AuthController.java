package com.topico.foroHub.Topico.controller;

import com.topico.foroHub.Topico.dto.LoginDTO;
import com.topico.foroHub.Topico.dto.JwtResponseDTO;
import com.topico.foroHub.Topico.service.AuthenticationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
public class AuthController {

    private final AuthenticationService authService;

    public AuthController(AuthenticationService authService) {
        this.authService = authService;
    }

    @PostMapping
    public ResponseEntity<JwtResponseDTO> login(@RequestBody LoginDTO loginDTO) {
        return ResponseEntity.ok(authService.login(loginDTO));
    }
}