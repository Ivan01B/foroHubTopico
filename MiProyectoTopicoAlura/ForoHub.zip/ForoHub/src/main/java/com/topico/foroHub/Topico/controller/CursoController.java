package com.topico.foroHub.Topico.controller;

import com.topico.foroHub.Topico.inicio.Curso;
import com.topico.foroHub.Topico.repository.CursoRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

    @RestController
    @RequestMapping("/api/cursos")
    public class CursoController {

        private final CursoRepository cursoRepository;

        public CursoController(CursoRepository cursoRepository) {
            this.cursoRepository = cursoRepository;
        }

        @GetMapping
        public List<Curso> listarCursos() {
            return cursoRepository.findAll();
        }

        @PostMapping
        public Curso crearCurso(@RequestBody Curso curso) {
            return cursoRepository.save(curso);
        }
    }