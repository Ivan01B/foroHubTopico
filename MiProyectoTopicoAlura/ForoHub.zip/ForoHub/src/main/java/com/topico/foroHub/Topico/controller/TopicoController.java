package com.topico.foroHub.Topico.controller;

import com.topico.foroHub.Topico.dto.TopicoDTO;
import com.topico.foroHub.Topico.inicio.*;
import com.topico.foroHub.Topico.repository.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/topicos")
public class TopicoController {

    private final TopicoRepository topicoRepo;
    private final CursoRepository cursoRepo;
    private final UsuarioRepository usuarioRepo;

    public TopicoController(TopicoRepository topicoRepo, CursoRepository cursoRepo, UsuarioRepository usuarioRepo) {
        this.topicoRepo = topicoRepo;
        this.cursoRepo = cursoRepo;
        this.usuarioRepo = usuarioRepo;
    }

    @PostMapping
    public ResponseEntity<?> registrarTopico(@RequestBody @Valid TopicoDTO datos) {
        if (topicoRepo.findByTituloAndMensaje(datos.titulo(), datos.mensaje()).isPresent()) {
            return ResponseEntity.badRequest().body("Tópico duplicado");
        }

        Optional<Curso> curso = cursoRepo.findById(datos.idCurso());
        Optional<Usuario> autor = usuarioRepo.findById(datos.idAutor());

        if (curso.isEmpty() || autor.isEmpty()) {
            return ResponseEntity.badRequest().body("Curso o autor no válidos");
        }

        Topico topico = new Topico();
        topico.setTitulo(datos.titulo());
        topico.setMensaje(datos.mensaje());
        topico.setCurso(curso.get());
        topico.setAutor(autor.get());
        topico.setStatus("NO_RESPONDIDO");
        topico.setFechaCreacion(LocalDateTime.now());

        topicoRepo.save(topico);

        return ResponseEntity.ok(topico);
    }

    @GetMapping
    public List<Topico> listarTopicos() {
        return topicoRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerTopico(@PathVariable Long id) {
        return topicoRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarTopico(@PathVariable Long id, @RequestBody @Valid TopicoDTO datos) {
        Optional<Topico> topicoOpt = topicoRepo.findById(id);
        if (topicoOpt.isEmpty()) return ResponseEntity.notFound().build();

        Optional<Curso> curso = cursoRepo.findById(datos.idCurso());
        Optional<Usuario> autor = usuarioRepo.findById(datos.idAutor());

        if (curso.isEmpty() || autor.isEmpty()) {
            return ResponseEntity.badRequest().body("Curso o autor no válidos");
        }

        Topico topico = topicoOpt.get();
        topico.setTitulo(datos.titulo());
        topico.setMensaje(datos.mensaje());
        topico.setCurso(curso.get());
        topico.setAutor(autor.get());
        topico.setStatus("NO_RESPONDIDO");
        topico.setFechaCreacion(LocalDateTime.now());

        topicoRepo.save(topico);
        return ResponseEntity.ok(topico);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarTopico(@PathVariable Long id) {
        if (!topicoRepo.findById(id).isPresent())
            return ResponseEntity.notFound().build();

        topicoRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}